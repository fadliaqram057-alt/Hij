export interface BusinessContext {
  businessType: string;
  targetMarket: string;
  whatsappNumber: string;
}

export interface GenerationRequirements {
  styles: string[]; // e.g., "modern", "professional"
  maxWords: number;
  avoidSymbols: boolean;
}

export interface GeneratedName {
  name: string;
  tagline: string;
  reasoning: string;
  domainAvailable: boolean; // Simulation
}

export interface GeneratorState {
  isLoading: boolean;
  error: string | null;
  results: GeneratedName[];
}