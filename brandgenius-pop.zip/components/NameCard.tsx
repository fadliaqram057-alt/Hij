import React from 'react';
import { GeneratedName } from '../types';
import { Globe, CheckCircle2, MessageCircle, Copy, Check } from 'lucide-react';

interface NameCardProps {
  data: GeneratedName;
  whatsappNumber: string;
}

export const NameCard: React.FC<NameCardProps> = ({ data, whatsappNumber }) => {
  const [copied, setCopied] = React.useState(false);

  const handleCopy = () => {
    navigator.clipboard.writeText(data.name);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleConsult = () => {
    const message = `Halo, saya tertarik dengan nama brand "${data.name}" yang digenerate di BrandGenius POP. Apakah tersedia untuk didaftarkan?`;
    const url = `https://wa.me/${whatsappNumber}?text=${encodeURIComponent(message)}`;
    window.open(url, '_blank');
  };

  return (
    <div className="group relative flex flex-col justify-between overflow-hidden rounded-2xl bg-white p-6 shadow-sm ring-1 ring-slate-200 transition-all hover:shadow-md hover:ring-indigo-200">
      <div className="absolute top-0 right-0 p-4 opacity-0 transition-opacity group-hover:opacity-100">
        <button 
          onClick={handleCopy}
          className="rounded-lg p-2 text-slate-400 hover:bg-slate-100 hover:text-slate-600"
          title="Copy name"
        >
          {copied ? <Check size={18} className="text-green-500" /> : <Copy size={18} />}
        </button>
      </div>

      <div className="mb-4">
        <div className="flex items-center gap-2 mb-2">
          <Globe className="h-4 w-4 text-indigo-500" />
          <span className="text-xs font-semibold uppercase tracking-wider text-indigo-500">
            Domain Available
          </span>
        </div>
        <h3 className="text-2xl font-bold text-slate-900 mb-1">{data.name}</h3>
        <p className="text-sm font-medium text-indigo-600 italic">"{data.tagline}"</p>
      </div>

      <div className="mb-6 flex-grow">
        <p className="text-sm leading-relaxed text-slate-600">
          {data.reasoning}
        </p>
      </div>

      <div className="flex gap-3 pt-4 border-t border-slate-100">
        <button 
          className="flex-1 flex items-center justify-center gap-2 rounded-lg bg-indigo-600 py-2.5 text-sm font-medium text-white shadow-sm hover:bg-indigo-700 transition-colors"
        >
          <CheckCircle2 size={16} />
          Register Now
        </button>
        <button 
          onClick={handleConsult}
          className="flex items-center justify-center rounded-lg border border-slate-200 bg-white p-2.5 text-slate-600 hover:bg-green-50 hover:border-green-200 hover:text-green-600 transition-colors"
          title="Consult via WhatsApp"
        >
          <MessageCircle size={20} />
        </button>
      </div>
    </div>
  );
};