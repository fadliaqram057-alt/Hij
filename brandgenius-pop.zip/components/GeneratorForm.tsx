import React from 'react';
import { BusinessContext, GenerationRequirements } from '../types';
import { Settings2, Loader2, Sparkles } from 'lucide-react';

interface GeneratorFormProps {
  context: BusinessContext;
  setContext: (ctx: BusinessContext) => void;
  requirements: GenerationRequirements;
  setRequirements: (req: GenerationRequirements) => void;
  onGenerate: () => void;
  isLoading: boolean;
}

export const GeneratorForm: React.FC<GeneratorFormProps> = ({
  context,
  setContext,
  requirements,
  setRequirements,
  onGenerate,
  isLoading
}) => {
  
  const handleStyleToggle = (style: string) => {
    if (requirements.styles.includes(style)) {
      setRequirements({
        ...requirements,
        styles: requirements.styles.filter(s => s !== style)
      });
    } else {
      setRequirements({
        ...requirements,
        styles: [...requirements.styles, style]
      });
    }
  };

  const styleOptions = ["Modern", "Profesional", "Mudah Diingat", "Tech-Forward", "Trustworthy", "Playful"];

  return (
    <div className="rounded-2xl bg-white p-6 shadow-xl shadow-slate-200/50 md:p-8 border border-slate-100">
      <div className="flex items-center gap-2 mb-6 text-slate-900">
        <Settings2 className="h-5 w-5 text-indigo-600" />
        <h2 className="text-lg font-bold">Configuration</h2>
      </div>

      <div className="space-y-6">
        {/* Business Type */}
        <div>
          <label className="mb-2 block text-sm font-semibold text-slate-700">Business Category</label>
          <input
            type="text"
            value={context.businessType}
            onChange={(e) => setContext({ ...context, businessType: e.target.value })}
            className="w-full rounded-lg border border-slate-300 px-4 py-2.5 text-sm text-slate-900 focus:border-indigo-500 focus:outline-none focus:ring-1 focus:ring-indigo-500 transition-shadow"
            placeholder="e.g., PPOB, Digital Payment, Top Up Game"
          />
        </div>

        {/* Target Market */}
        <div>
          <label className="mb-2 block text-sm font-semibold text-slate-700">Target Market</label>
          <select
            value={context.targetMarket}
            onChange={(e) => setContext({ ...context, targetMarket: e.target.value })}
            className="w-full rounded-lg border border-slate-300 px-4 py-2.5 text-sm text-slate-900 focus:border-indigo-500 focus:outline-none focus:ring-1 focus:ring-indigo-500 bg-white"
          >
            <option value="Indonesia">Indonesia (General)</option>
            <option value="Mahasiswa & Pelajar">Students & Youth</option>
            <option value="UMKM & Warung">MSMEs & Warung</option>
            <option value="Gamers">Gamers</option>
          </select>
        </div>

        {/* WhatsApp Number (Hidden config mostly, but exposed for flexibility) */}
        <div>
          <label className="mb-2 block text-sm font-semibold text-slate-700">WhatsApp Contact</label>
          <div className="relative">
            <span className="absolute left-4 top-2.5 text-sm text-slate-500">+62</span>
            <input
              type="text"
              value={context.whatsappNumber.replace(/^62/, '')} // Visual formatting
              onChange={(e) => setContext({ ...context, whatsappNumber: e.target.value })}
              className="w-full rounded-lg border border-slate-300 pl-12 pr-4 py-2.5 text-sm text-slate-900 focus:border-indigo-500 focus:outline-none focus:ring-1 focus:ring-indigo-500 transition-shadow"
              placeholder="81234567890"
            />
          </div>
        </div>

        {/* Styles */}
        <div>
          <label className="mb-3 block text-sm font-semibold text-slate-700">Brand Vibe</label>
          <div className="flex flex-wrap gap-2">
            {styleOptions.map((style) => (
              <button
                key={style}
                onClick={() => handleStyleToggle(style)}
                className={`rounded-full px-3 py-1.5 text-xs font-medium transition-all ${
                  requirements.styles.includes(style)
                    ? 'bg-indigo-100 text-indigo-700 ring-1 ring-indigo-500'
                    : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                }`}
              >
                {style}
              </button>
            ))}
          </div>
        </div>

        {/* Generate Button */}
        <button
          onClick={onGenerate}
          disabled={isLoading}
          className="group relative flex w-full items-center justify-center gap-2 overflow-hidden rounded-xl bg-indigo-600 py-3.5 text-sm font-bold text-white shadow-lg shadow-indigo-600/30 transition-all hover:bg-indigo-700 hover:scale-[1.01] active:scale-[0.99] disabled:cursor-not-allowed disabled:opacity-70"
        >
          {isLoading ? (
            <>
              <Loader2 className="animate-spin" size={18} />
              Generating Names...
            </>
          ) : (
            <>
              <Sparkles className="transition-transform group-hover:rotate-12" size={18} />
              Generate Brand Names
            </>
          )}
        </button>
      </div>
    </div>
  );
};