import React, { useState } from 'react';
import { Header } from './components/Header';
import { GeneratorForm } from './components/GeneratorForm';
import { NameCard } from './components/NameCard';
import { BusinessContext, GeneratedName, GenerationRequirements } from './types';
import { generateBrandNames } from './services/geminiService';
import { AlertCircle, Wallet, ArrowRight, Sparkles } from 'lucide-react';

const App: React.FC = () => {
  // Default State based on user prompt requirements
  const [context, setContext] = useState<BusinessContext>({
    businessType: "POP (Point of Payment / Online Payment / PPOB)",
    targetMarket: "Indonesia",
    whatsappNumber: "6282277930100" 
  });

  const [requirements, setRequirements] = useState<GenerationRequirements>({
    styles: ["Modern", "Profesional", "Mudah Diingat"],
    maxWords: 3,
    avoidSymbols: true
  });

  const [results, setResults] = useState<GeneratedName[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleGenerate = async () => {
    setIsLoading(true);
    setError(null);
    setResults([]); // Clear previous results for dramatic effect

    try {
      const generatedNames = await generateBrandNames(context, requirements);
      setResults(generatedNames);
    } catch (err: any) {
      setError(err.message || "Something went wrong. Please try again.");
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-slate-50 font-sans">
      <Header />

      <main className="flex-grow">
        {/* Hero Section */}
        <section className="relative overflow-hidden bg-slate-900 px-4 py-20 text-center sm:px-6 lg:px-8">
            <div className="absolute inset-0 z-0 opacity-20 bg-[url('https://images.unsplash.com/photo-1556742049-0cfed4f7a07d?ixlib=rb-4.0.3&auto=format&fit=crop&w=2070&q=80')] bg-cover bg-center mix-blend-overlay"></div>
            <div className="absolute inset-0 z-0 bg-gradient-to-t from-slate-900 via-transparent to-slate-900/80"></div>
            
            <div className="relative z-10 mx-auto max-w-3xl">
              <div className="mb-6 inline-flex items-center rounded-full bg-indigo-500/10 px-3 py-1 text-sm font-medium text-indigo-300 ring-1 ring-inset ring-indigo-500/20 backdrop-blur-sm">
                <span className="mr-2 flex h-2 w-2 relative">
                    <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-indigo-400 opacity-75"></span>
                    <span className="relative inline-flex rounded-full h-2 w-2 bg-indigo-500"></span>
                </span>
                AI-Powered for PPOB Business
              </div>
              <h1 className="mb-6 text-4xl font-extrabold tracking-tight text-white sm:text-5xl lg:text-6xl">
                Create the Perfect Brand for Your <span className="text-transparent bg-clip-text bg-gradient-to-r from-indigo-400 to-cyan-400">Digital Payment</span> Business
              </h1>
              <p className="mx-auto mb-10 max-w-2xl text-lg text-slate-400">
                Generate professional, catchy, and localized brand names optimized for the Indonesian market in seconds. Powered by advanced AI.
              </p>
            </div>
        </section>

        <section className="container mx-auto px-4 py-12 sm:px-6 lg:px-8 -mt-10 relative z-20">
          <div className="grid grid-cols-1 gap-8 lg:grid-cols-12">
            
            {/* Left Column: Form */}
            <div className="lg:col-span-4 xl:col-span-3">
              <div className="sticky top-24">
                <GeneratorForm 
                  context={context} 
                  setContext={setContext}
                  requirements={requirements}
                  setRequirements={setRequirements}
                  onGenerate={handleGenerate}
                  isLoading={isLoading}
                />
                
                <div className="mt-6 rounded-xl bg-white p-4 shadow-sm border border-slate-100">
                    <div className="flex items-start gap-3">
                        <div className="p-2 bg-green-50 rounded-lg">
                            <Wallet className="w-5 h-5 text-green-600" />
                        </div>
                        <div>
                            <h4 className="font-semibold text-slate-900 text-sm">Need Payment Integration?</h4>
                            <p className="text-xs text-slate-500 mt-1 mb-2">Connect your new brand with top Indonesian payment gateways.</p>
                            <a href="#" className="text-xs font-medium text-indigo-600 hover:text-indigo-700 flex items-center gap-1">
                                Learn more <ArrowRight size={12} />
                            </a>
                        </div>
                    </div>
                </div>
              </div>
            </div>

            {/* Right Column: Results */}
            <div className="lg:col-span-8 xl:col-span-9">
              {error && (
                <div className="mb-8 flex items-center gap-3 rounded-lg border border-red-200 bg-red-50 p-4 text-red-800">
                  <AlertCircle size={20} />
                  <p>{error}</p>
                </div>
              )}

              {results.length > 0 ? (
                <div>
                  <div className="mb-6 flex items-center justify-between">
                    <h2 className="text-2xl font-bold text-slate-900">Generated Brands</h2>
                    <span className="text-sm text-slate-500">{results.length} results found</span>
                  </div>
                  <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-2 xl:grid-cols-3">
                    {results.map((nameData, index) => (
                      <NameCard 
                        key={index} 
                        data={nameData} 
                        whatsappNumber={context.whatsappNumber}
                      />
                    ))}
                  </div>
                </div>
              ) : (
                <div className="flex h-96 flex-col items-center justify-center rounded-3xl border-2 border-dashed border-slate-200 bg-slate-50/50 p-12 text-center">
                  {isLoading ? (
                     <div className="flex flex-col items-center">
                        <div className="h-12 w-12 animate-spin rounded-full border-4 border-indigo-200 border-t-indigo-600"></div>
                        <p className="mt-4 font-medium text-indigo-600">Consulting AI Strategy...</p>
                        <p className="text-sm text-slate-400 mt-1">Analyzing market trends for {context.targetMarket}</p>
                     </div>
                  ) : (
                    <>
                        <div className="mb-4 rounded-full bg-white p-4 shadow-sm ring-1 ring-slate-100">
                            <Sparkles className="h-8 w-8 text-indigo-300" />
                        </div>
                        <h3 className="text-lg font-semibold text-slate-900">Ready to start?</h3>
                        <p className="mt-2 max-w-sm text-sm text-slate-500">
                            Configure your preferences on the left and click "Generate" to see AI-crafted brand names for your business.
                        </p>
                    </>
                  )}
                </div>
              )}
            </div>
          </div>
        </section>
      </main>

      <footer className="border-t border-slate-200 bg-white py-8 mt-auto">
        <div className="container mx-auto px-4 text-center text-sm text-slate-500">
          <p>&copy; {new Date().getFullYear()} BrandGenius POP. All rights reserved.</p>
          <p className="mt-2 text-xs">Powered by Gemini AI. Designed for Indonesian Payment Businesses.</p>
        </div>
      </footer>
    </div>
  );
};

export default App;