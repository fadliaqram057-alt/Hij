import { GoogleGenAI, Type } from "@google/genai";
import { BusinessContext, GeneratedName, GenerationRequirements } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const generateBrandNames = async (
  context: BusinessContext,
  requirements: GenerationRequirements
): Promise<GeneratedName[]> => {
  const modelId = "gemini-3-flash-preview";

  const prompt = `
    You are a professional branding consultant specializing in the Indonesian Fintech and PPOB (Payment Point Online Bank) market.
    
    Task: Generate 6 professional, catchy, and domain-friendly website names based on the following context.
    
    Context:
    - Business Type: ${context.businessType}
    - Target Market: ${context.targetMarket}
    
    Requirements:
    - Styles: ${requirements.styles.join(", ")}
    - Max Words: ${requirements.maxWords}
    - Avoid Symbols: ${requirements.avoidSymbols}
    - Language: Indonesia (Bahasa Indonesia) or English-Indonesian hybrid appropriate for local market.
    
    Output structured JSON data containing the name, a short catchy tagline (slogan) in Indonesian, a brief reasoning why it fits the market, and a simulated domain availability check (always true for this exercise).
  `;

  try {
    const response = await ai.models.generateContent({
      model: modelId,
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              name: { type: Type.STRING, description: "The generated brand name" },
              tagline: { type: Type.STRING, description: "A catchy slogan in Indonesian" },
              reasoning: { type: Type.STRING, description: "Why this name works for the Indonesian PPOB market" },
              domainAvailable: { type: Type.BOOLEAN, description: "Always return true for this simulation" },
            },
            required: ["name", "tagline", "reasoning", "domainAvailable"],
          },
        },
      },
    });

    const text = response.text;
    if (!text) return [];
    
    return JSON.parse(text) as GeneratedName[];
  } catch (error) {
    console.error("Gemini API Error:", error);
    throw new Error("Failed to generate names. Please try again.");
  }
};